## Sorting Algos Checklist

- [x] Bubble Sort
- [] Insertion Sort
- [] Selection Sort
- [] Merge Sort
- [] Quick Sort
- [] Heap Sort

