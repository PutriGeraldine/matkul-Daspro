#include <stdio.h>

int main() {
	printf("hello again world!\n");
	printf("There are %d students taking the %s class.\n", 27, "C programming");
	return 0;
}

