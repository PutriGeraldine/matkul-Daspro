#include <stdio.h>

int main() 
{
  int marks = 90; //assignment

	if (marks == 100) //equality
	{
	    printf("Perfect score!\n");
	} 
	else 
	{
	    printf("Great effort!\n");
	}
  
  return 0;
}
